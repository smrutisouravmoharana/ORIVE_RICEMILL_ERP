package com.orive.erp.paypal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class  PaypalPaymentGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(PaypalPaymentGatewayApplication.class, args);
	}

}
