package com.orive.token;

public enum TokenType {
	  BEARER
	}
