package com.orive;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OriveAuthServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
